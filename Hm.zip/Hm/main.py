from base64 import encodebytes
from base64 import decodebytes

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding

# Load private key from file
def load_private_key(file_path):
    return serialization.load_pem_private_key(
        open(file_path, "rb").read(),
        password=None
    )

def load_public_key(file_path):
    return serialization.load_pem_public_key(
        open(file_path, "rb").read()
    )

def encrypt_bytes(key, message: bytes) -> bytes:
    """Using public key"""
    ciphertext = key.encrypt(
        message,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return ciphertext

def sign_bytes(message: bytes) -> bytes:
    """Using private key"""
    signature = PRIVATE_KEY.sign(
        message,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )    
    return signature

def encrypt_message(reciver_key, message: str) -> tuple[bytes, bytes]:
    message_bytes = bytes(message, "utf-8")
    ciphertext_bytes = encrypt_bytes(reciver_key, message_bytes)
    ciphertext_base64 = encodebytes(ciphertext_bytes)

    signature_bytes = sign_bytes(message_bytes)
    signature_base64 = encodebytes(signature_bytes)
    return ciphertext_base64, signature_base64

def decrypt_bytes(ciphertext: bytes) -> bytes:
    """Using private key"""
    plaintext = PRIVATE_KEY.decrypt(
        ciphertext,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return plaintext

def verify_bytes(key, signature: bytes, plaintext: bytes) -> bool:
    """Using public key"""
    try:
        key.verify(
            signature,
            plaintext,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
    except:
        return False
    else:
        return True

def decrypt_message(sender_key, ciphertext: bytes, signature: bytes) -> tuple[str, bool]:
    ciphertext_bytes = decodebytes(ciphertext)
    plaintext_bytes = decrypt_bytes(ciphertext_bytes)
    plaintext = plaintext_bytes.decode("utf-8")

    signature_bytes = decodebytes(signature)
    verified = verify_bytes(sender_key, signature_bytes, plaintext_bytes)
    return plaintext, verified


if __name__ == "__main__":
    def strip(s):
        return s.replace('\n', ' ').replace('\r', '').replace(" ", "")
    PRIVATE_KEY = load_private_key("private.pem")
    PUBLIC_KEY = PRIVATE_KEY.public_key()

    CONVO_KEY = load_public_key(input("Convo key: "))
    # CONVO_KEY = load_public_key("public.pem")
    
    while True:
        if input("\n[E]ncryption / [D]ecryption: \n>>> ").lower() == "e":
            message = input("Message: \n>>> ")
            ciphertext, signature = encrypt_message(CONVO_KEY, message)
            ciphertext, signature = ciphertext.decode(), signature.decode()
            print("\nCiphertext: \n{} \n\nSignature: \n{} ".format(strip(ciphertext), strip(signature)))
            
        else:
            ciphertext = bytes(input("Ciphertext: \n>>> "), "utf-8")
            signature = bytes(input("Signature: \n>>> "), "utf-8")
            plaintext, verified = decrypt_message(CONVO_KEY, ciphertext, signature)
            print("\nPlaintext: \n{} \n\nSender Verified as {}: \n{} ".format(plaintext, CONVO_KEY, verified))